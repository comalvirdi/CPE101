#Lab 2 Test Cases
#Name:
#Section:
##############################################################
import unittest
import funcs

class TestCases(unittest.TestCase):
   def test_math_func1(self):
      # Add code here.
      pass


   def test_math_func2(self):
      # Add code here.
      pass

   def test_d(self):
      # Add code here.
      pass
      
   def test_is_negative(self):
      # Add code here.
      pass

   def test_dividable_by_5(self):
      # Add code here.
      pass

# Run the unit tests.
if __name__ == '__main__':
   unittest.main()

