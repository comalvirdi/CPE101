import unittest
from objects import *

class TestCases(unittest.TestCase):
   def test_point(self):
      # Add code here.
      pass


   def test_circle(self):
      # Add code here.
      pass

   # Add other testing functions


# Run the unit tests.
if __name__ == '__main__':
   unittest.main()

