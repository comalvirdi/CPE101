import unittest
from objects import *

class TestCases(unittest.TestCase):
   def test_equality(self):
      # Add test here
      pass


# Run the unit tests.
if __name__ == '__main__':
   unittest.main()

