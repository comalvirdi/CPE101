# Project 3
# 
# Name: 
# Instructor: S. Einakian
# Section: 
'''
Some of the suggested functions are shown bellow.
You can create as many functions as you need. 
You can even ignore the suggested functions.
But you are not allow to write the whole project in One Function!
'''
#1) gets input for puzzle

#2) checks forward for given word

#3) checks backward for given word

#4) checks up for given word

#5) checks down for given word

