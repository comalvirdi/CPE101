import unittest
import conditional
#You can delete pass after wrinting your code
class TestCases(unittest.TestCase):
   def test_max_101(self):
      # Add code here.
      pass


# Run the unit tests.
if __name__ == '__main__':
   unittest.main()

