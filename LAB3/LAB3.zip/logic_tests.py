import unittest
import logic

#You can dlete pass after wrinting your code
class TestCases(unittest.TestCase):
   def test_is_even(self):
      # Add code here.
      pass


# Run the unit tests.
if __name__ == '__main__':
   unittest.main()

