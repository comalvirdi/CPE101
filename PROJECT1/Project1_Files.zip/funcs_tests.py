# Project 1 
# 
# Name: Your Name
# Instructor: S. Einakian 
# Section: Your Section

import unittest
from funcs import *

class TestCases(unittest.TestCase):
          
   def test_poundsToKG1(self):

      

# Run the unit tests.
if __name__ == '__main__':
   unittest.main()

